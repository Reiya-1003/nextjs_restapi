const engineer = [
    { name : 'tobita',gengo : ['Java','PHP','Linux','Javascript']} 

];

console.log('tobitaさんの使用できる言語は'+engineer[0].gengo )

engineer[0].gengo.push('QA')
console.log('新しく'+engineer[0].gengo[4]+'を使えるようになりました。')


for(let hyaku = 1 ; hyaku <= 100 ; hyaku++){

    if(hyaku%15 === 0){
        console.log(hyaku+'は15の倍数です')
      }else if(hyaku%5 === 0){
        console.log(hyaku+'は5の倍数です')
      }else if(hyaku%3 === 0){
         console.log(hyaku+'は3の倍数です')
          } else if(!hyaku%15===0 && !hyaku%5 === 0 && !hyaku%3 === 0){
            console.log(hyaku)
        }
    }

let kuku = "";
for(let a =1; a < 10; a++){
    for (let b =1; b < 10; b++){
        if(a * b < 10) {
            kuku +="  " + a * b
        }else　if(a * b >= 10){
            kuku +=" " + a * b
        }

}
}

console.log(kuku)



let nen= 2000

function seiki(nen){
    const modori= (nen-1)/100+1
    return modori
}

seiki2 = function(nen){
    return (nen-1)/100+1
}

let a=seiki(nen)
let b = Math.floor(a) ;


console.log(nen+'年は'+b+'世紀です')

let urnen = 2100;
function uruu(dosi){
    if( (dosi % 4 === 0 && dosi % 100 !== 0) || dosi % 400 === 0) {
      return true;
    }
    return false;
  }
  

  if(uruu(urnen)){
    console.log(urnen + '年はうるう年です');
  }else{
    console.log(urnen + '年はうるう年ではありません');
  }

  let z=1
  let x=3
  let y=5
 
